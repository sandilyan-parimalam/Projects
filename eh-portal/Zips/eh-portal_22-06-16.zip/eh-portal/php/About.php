<!DOCTYPE html>
<!--
        Author: Sandy,HSG
        Description : This is an about page
-->

<html>

	<head>
		<title> About EH Portal </title>
                <link rel="stylesheet" type="text/css" href="/eh-portal/css/about.css">
		 <meta charset="UTF-8">


	</head>

	<body>
		<dia> 
			<h1>About Ebix Health Portal</h1>
		<table>
		<tr>
			<th>Author</th> <th>Sandy</th>
		</tr>
		<tr>
			<th>Email</th>	<th>Sandilyan.parimalam@ebix.com</th>
		</tr>
		<tr>
			<th>Copyrights</th> <th>Ebix Inc</th>
		</tr>

		<tr>
			<th>From </th><th>2015</th>
		</tr>
		</table>
<p><font color=green><u><b>High Level View:</b></u></font> Ebix health portal was developed to automate all the daily troubleshooting activities for Ebix health. It will provide you the control to handle all the services of EH  from this web based web interface. You can stop, start and any LX and LIN services also you can get the real time status of all the services of each clients.<br></p>

<p><font color=green><u><b>Technical View:</b></u></font> This Portal was developed by HTML, CSS, PHP, Java Script, JQuery and shell scripts. Shell scripts are the real components which login in and works on servers. This portal run on the servers as ‘www-data’ user. This portal is integrate with LDAP authentication to provide easy account management. It also generate its own activity tracing log which is available under Logs directory will provide you the information about the all user activities.</p>
	

		</div>


	</body>



</html>
