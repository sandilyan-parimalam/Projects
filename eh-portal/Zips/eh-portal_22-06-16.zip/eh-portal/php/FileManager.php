<!DOCTYPE html>

<!--
        Author: Sandy,HSG
	Email:sandilyan.parimalam@ebix.com
        Description : This is a simple file manager which will help you to browse through the files and folders also allows to download the files
-->

<html>

	<head>
		 <meta charset="UTF-8">
                <link rel="stylesheet" type="text/css" href="/eh-portal/css/FileManager.css">

                <?php

                        if(!empty($_GET['downloadfile'])) {
                                        $Server=$_GET['svr'];
                                        $FileName=$_GET['downloadfile'];
                                        $handle = popen("/opt/scripts/eh_portal_scripts/bin/FileManagerHelper.sh download $Server $FileName", "r");
                                        while (!feof($handle)) {
                                                $data = fgets($handle);
                                                echo " ".$data;
                                        }
                                        die();
                        }

                        if(!empty($_GET['targetdirname'])) {

                                        $Server=$_GET['svr'];
                                        $Client=$_GET['client'];
                                        $TargetDirName=$_GET['targetdirname'];

                                        $handle = popen("/opt/scripts/eh_portal_scripts/bin/FileManagerHelper.sh NavigateDir $Server $Client $TargetDirName", "r");
                                        while (!feof($handle)) {
                                                $data = fgets($handle);
                                                echo " ".$data;
						
                                        }
                                        die();

                        }

			if(!empty($_GET['targetfilename'])) {
                                        $Server=$_GET['svr'];
					$Client=$_GET['client'];
					$TargetFileName=$_GET['targetfilename'];

                                        $handle = popen("/opt/scripts/eh_portal_scripts/bin/FileManagerHelper.sh showtextfilecontent $Server $Client $TargetFileName", "r");
                                        while (!feof($handle)) {
                                                $data = fgets($handle);
                                                echo " ".$data;
                                        }
                                        die();

			}

			if (!empty($_GET['client'])) {
                                        $Server=$_GET['svr'];
                                        $Client=$_GET['client'];
                                        $handle = popen("/opt/scripts/eh_portal_scripts/bin/FileManagerHelper.sh NavigateDir $Server $Client", "r");
                                        while (!feof($handle)) {
                                                $data = fgets($handle);
                                                echo "<br> ".$data;
                                        }

                                        die();

			}

                         if(!empty($_GET['svr'])) {
        	                        $Server=$_GET['svr'];
					echo "<option selected disabled> Select Client </option>";
                        	        $handle = popen("/opt/scripts/eh_portal_scripts/bin/FileManagerHelper.sh getclientlist $Server", "r");
	 				while (!feof($handle)) {
						$data = fgets($handle);
						echo " ".$data;
					}
					die();
				}
		
                ?>

		<title> File Manager </title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js" > </script>
		<script type="text/javascript" src="../conf/LogViewer/LogServersConf.js" ></script>
		<script>

		function Download(filename) {
                 var server = document.getElementById("ServerList").value;
			    $('#dummy').html('<img src="../images/loader.gif" class=loader></img>');
                            $.get('FileManager.php?svr='+server+'&downloadfile='+filename, function(result){
                                     $('#dummy').html(result);
                                });

		}

		function ShowLog(targetfilename) {
                                var server = document.getElementById("ServerList").value;
                                var client = document.getElementById("ClientList").value;
                            $('#Content').html('<img src="../images/loader.gif" class=loader></img>');
                                $.get('FileManager.php?svr='+server+'&client='+client+'&targetfilename='+targetfilename, function(result){
                                     $('#Content').html(result);
				});

		}

                function NavigateDir(targetdirname) {
                                var server = document.getElementById("ServerList").value;
                                var client = document.getElementById("ClientList").value;
                            $('#Content').html('<img src="../images/loader.gif" class=loader></img>');
                                $.get('FileManager.php?svr='+server+'&client='+client+'&targetdirname='+targetdirname, function(result){
                                     $('#Content').html(result);
                                });

                };


			function HideAll() {

				document.getElementById("ServerList").style.display = "none";
                                document.getElementById("ClientList").style.display = "none";

			}

			function LoadNextBox(SelectedBoxName) {
				
				if (SelectedBoxName == "ActionType") {
			
					LoadServerList()


				}else if (SelectedBoxName == "ServerList") {

					LoadClientList()
				}

			function LoadServerList() {

				var SelectedAction = document.getElementById("ActionType").value;
                               jQuery('#Content').html('');
                                if (SelectedAction == "Browse LIN Servers") {
					alert("This function is under construction");
					exit;
				}
                                if (SelectedAction == "Browse LX Servers") {
					if (typeof LXServers != 'undefined' && LXServers) {
					       var LXServersList_array=LXServers.split(',');
		                               var Options="<option selected disabled>Select LX Server </option>";

						for(var i = 0; i < LXServersList_array.length; i++) {
							var Options=Options+"<option value="+LXServersList_array[i]+">"+LXServersList_array[i]+" </option>"
						}
                        	                document.getElementById("ServerList").innerHTML = Options;
                                	        document.getElementById("ServerList").style.display = "inline";
					} else {

						alert("There is no LX Servers in Config file\nFile : eh-portal/conf/LogViewer/LogServersConf.js\nSyntax :LXServers=\"Server1,Server2\"");
						
					}
				}else {

	                               jQuery('#ServerList').hide();
        	                       jQuery('#ClientList').hide();

			
				}


			}


			$(function(){

			   $('#ServerList').change(function(){

			       if($(this).val() !== "Select LX") {
                            $('#Content').html('<img src="../images/loader.gif" class=loader></img>');
			           $.get('FileManager.php?svr='+ $(this).val(), function(result){
			               $('#ClientList').html(result);
					$('#ClientList').show();
					$('#Content').html('');

			           });

       				}

   				});
	
			});

                        $(function(){

                           $('#ClientList').change(function(){
                               if($(this).val() !== "Select Client") {
				var server = $('#ServerList').find(":selected").text();
                            $('#Content').html('<img src="../images/loader.gif" class=loader></img>');
                                   $.get('FileManager.php?svr='+server+'&client='+ $(this).val(), function(result){
                                       $('#Content').html(result);


                                   });

                                }

                                });

                        });

	}



		</script>

	</head>

	<body onload="HideAll()">
		<h3> Ebix Health File Manager </h3>

		<div id="FilterBox">
			<div class='select_style'><select id="ActionType" onchange="LoadNextBox('ActionType')">
				<option selected disabled> Select Type </option>
				<option id="browse"> Browse LX Servers </option>
                                <option id="test"> Browse LIN Servers </option>


			</select></div>

		<div class='select_style'><select id="ServerList"> 


			</select></div>

                        <div class='select_style'><select id="ClientList">



                        </select></div>

		</div>

                <div id="ContentContainer">
			<div id="Content">

			</div>
			<div id=dummy></div>
			
		</div>

	</body>

</html>
